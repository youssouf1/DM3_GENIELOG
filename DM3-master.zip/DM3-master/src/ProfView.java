public class ProfView extends View{
	

	public void print_menu() {
	}

}