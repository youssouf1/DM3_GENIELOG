public class Membre extends Humain {

	public Membre(String firstName, String lastName, String phone, String address, String email) {
	super(firstName, lastName, phone, address, email);
	
    }

	public Membre() {
	    // TODO Auto-generated constructor stub
	}

	private double sold;
	private boolean is_active;
	public boolean Is_active() {
	    return is_active;
	}
	public void setIs_active(boolean is_active) {
	    this.is_active = is_active;
	}
	public double getSold() {
	    return sold;
	}
	public void setSold(double sold) {
	    this.sold = sold;
	}
	
	
	
}