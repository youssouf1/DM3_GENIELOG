

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    public static String verifyDateFormat(String message) throws IOException {
        String datePattern = "^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\\d{4}$";
        Pattern pattern = Pattern.compile(datePattern);
        return verify(message, pattern, "JJ-MM-YYYY");
    }

    public static String verifyHoursFormat(String message) throws IOException {
        Pattern pattern = Pattern.compile("^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$");
        return verify(message, pattern, "HH-MM");
    }

    public static String verify(String message, Pattern pattern, String format) throws IOException {
        Matcher m;
        String s;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int counter = 0;

        do {
            System.out.println(message);
            if (counter++ > 0) {
                System.out.println("Erreur: format n'a pas été bon, veuillez répéter");
                System.out.println("Format désiré: " + format);
            }
            s = reader.readLine();
            m = pattern.matcher(s);

        } while (!m.find());
        return s;
    }

    
  
    public static String promptStringValuerWithMinAndMaxLength(String message, int minLength, int maxLength) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int counter = 0;
        String s;

        do {
            if (counter++ > 0) {
                System.out.println("Erreur: min " + minLength + ", max " + maxLength + " charactèrs, veuillez réessayer");
            }
            System.out.println(message);
            s = reader.readLine();
            if(s.equals("non")) break;
        } while (s.length() < minLength || s.length() > maxLength);
        return s;
    }

    public static int promptIntValueWithLength(String message, int desiredLength) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Integer res;
        int counter = 0;
        int length;
        do {
            if (counter++ > 0) {
                System.out.println("Erreur: format n'a pas été bon, veuillez répéter");
            }
            System.out.println("\n" + message);
            String s = reader.readLine();
            length = s.length();
            res = tryParse(s);
            if (res == null) {
                System.out.println("Seulement des nombres entiers sont acceptés");
            }
            else if (length != desiredLength) {
                System.out.println("Longeur n'est pas égale à " + desiredLength);
            }
        } while (res == null || res < 0 || length != desiredLength);
        return res;
    }

    public static int promptIntValueWithUpperBond(String message, int desiredValue) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Integer res;
        int counter = 0;
        int length = 0;
        do {
            System.out.println(message);
            if (counter++ > 0) {
                System.out.println("Erreur: format n'a pas été bon, veuillez répéter");
            }
            String s = reader.readLine();
            if(s.equalsIgnoreCase("non")) return -1;
            res = tryParse(s);
            if (res == null) {
                System.out.println("Seulement des nombres entiers sont acceptés");
            } else if (res > desiredValue) {
                System.out.println("Valeur ne doit pas être plus grand que " + desiredValue);
            }
        } while (res == null || res < 0 || res > desiredValue);
        return res;
    }

    public static int promptIntValue(String message) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Integer res;
        int counter = 0;
        do {
            System.out.println(message);
            if (counter++ > 0) {
                System.out.println("Erreur: format n'a pas été bon, veuillez répéter");
            }
            String s = reader.readLine();
            res = tryParse(s);
            if (res == null) System.out.println("Seulement des nombres entiers positifs sont acceptés");
        } while (res == null || res < 0 );
        return res;
    }



    public static Integer tryParse(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
