public class Professionnel extends Humain {

    
    	private String occupation;
    	
	public  Professionnel(String firstName, String lastName, String phone, String address,
		String email) {
	    
	    super(firstName, lastName, phone, address, email);
	   
	}  


 

    public Professionnel(String firstName, String name, String phone, String address, String city, String province,
		String zip_code, String email) {
	 this( firstName,  name,  phone,  address, email);
	 this.setProvince(province);
	 this.setCity(city);
	 this.setZip_code(zip_code);
	 
	}




    public String getOccupation() {
	return occupation;
    }

    public void setOccupation(String occupation) {
	this.occupation = occupation;
    }
	
}