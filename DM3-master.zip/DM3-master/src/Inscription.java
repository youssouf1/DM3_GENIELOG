import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Inscription{
	
    	
	private Session session;

	private Membre curr_member;

	private String date_creation;

	private String date_debut;

	private boolean is_confirmed;

	private String comments;
	
	private ServiceController service_control = ServiceController.getInstance();
	
	public Inscription(ServiceController sc) {
	    
	    this.service_control = sc;
	    this.session = new Session();
	    
	}
	
	public void subscribe(Membre curr) {
	    
	  Service c = service_control.getServiceToday(session.getDay());
	  if(c == null) return;
	  Scanner sc = new Scanner(System.in);
	  if(curr == null) {
	      System.out.println("Entrez le numero unique a 9 chiffres du membre");
	      int codeClient = Utils.tryParse(sc.nextLine());
	      curr = MemberController.getInstace().get_member(codeClient);
	      if(curr == null) {
		  System.out.println("numero du membre incorrect");
	      }
	  }
	 
	  if(!curr.Is_active()) {
	      System.out.println("Membre suspendu : frais impayes");
	  }
	  System.out.println("1 .confirmer l'inscription");
	  System.out.println("2 .Annuler l'inscription");
	  String res = sc.nextLine();
	  if(res.equals("1")) {
	      SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	      String date_now = formatter.format(new Date());
	      System.out.println("Rentrez des commentaires (facultatif)");
	      
	      String comments = sc.nextLine();
	      c.inscrireMembre(curr);
	      System.out.println("recherches des frais a payer pour le service ...");
	      try {
		  Thread.sleep(5000);
	      }catch(Exception e) {
		  
	      }
	      System.err.println("frais a payer " + c.getFees() +"$");
	      
	      System.out.println("Inscription faite");
	      System.out.println("Date actuelle : " + date_now);
	      System.out.println("Date à laquelle du service qui sera fourni (JJ-MM-AAAA)" + c.getStart_date());
	      System.out.println("Numéro du professionnel " + c.getProf_num());
	      System.out.println("Numéro du membre " + curr.getUid());
	      System.out.println("Code du service " + c.getService_code());
	      System.out.println("Commentaires " + comments);
	      System.out.println();
	  }
	  
	  
	  
	  
	}
	public void confirm(Membre m) {
	    Service c = service_control.getServiceToday(session.getDay());
	    if(c == null) return;
	    Scanner sc = new Scanner(System.in);
	    if(m == null) {
		System.out.println("Entrez le numero unique a 9 chiffres du membre");
		int codeClient = Utils.tryParse(sc.nextLine());
		m = MemberController.getInstace().get_member(codeClient);
		if(m == null) {
		    System.out.println("Numéro du membre incorrect");
		    return;
		}
	    }
	    
	  
	    if(!m.Is_active()) {
		System.out.println("Membre suspendu : frais impayes");
	    }
	    if(!c.est_inscrire(m.getUid())) {
		System.out.println("Membre non inscrit a la seance ");
		return;
	    }
	    System.out.println("1 .confirmer l'inscription");
	    System.out.println("2 .Annuler l'inscription");
	    String res = sc.nextLine();
	    if(res.equals("1")) {
		      SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		      String date_now = formatter.format(new Date());
		      System.out.println("Rentrez des commentaires (facultatif)");
		      
		      String comments = sc.nextLine();
		      
		      System.err.println("Inscription confirmée");
		      System.out.println("Date actuelle : " + date_now);
		      System.out.println("Numéro du professionnel " + c.getProf_num());
		      System.out.println("Numéro du membre " + m.getUid());
		      System.out.println("Code du service " + c.getService_code());
		      System.out.println("Commentaires " + comments);
		      System.out.println();
	

			  
	    }
		      
		  
	}
	    
	
	public String getDate_creation() {
	    return date_creation;
	}

	public void setDate_creation(String date_creation) {
	    this.date_creation = date_creation;
	}

	public String getDate_debut() {
	    return date_debut;
	}

	public void setDate_debut(String date_debut) {
	    this.date_debut = date_debut;
	}

	public boolean isIs_confirmed() {
	    return is_confirmed;
	}

	public void setIs_confirmed(boolean is_confirmed) {
	    this.is_confirmed = is_confirmed;
	}

}