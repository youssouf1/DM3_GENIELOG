import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;




public class MemberController {

	private IRepertoire manager;
	
	private static MemberController single;
	
	private RepertoireClient repository = RepertoireClient.getInstance();
	
	/**
	 * Utiliser une seule instance de cette classe
	 * 
	 * @return
	 */
	public static MemberController getInstace() {
	    
	 return  (single == null) ? new MemberController() :single;
	}
	
	
	public void create_member(String name, String lastName, String address){
	    
	    Membre member = new Membre();
	    member.setFirstName(name);
	    
	    member.setLastName(lastName);
	    member.setAddresse(address);
	    member.setIs_active(false);
	    
	   
		
	}

	public void update_member(String id){

	}

	public void delete_member(){
	    int uid;
	    try {
	  	uid = Utils.promptIntValueWithLength("Entrez le code unique du client", 9);
	  		
	    } catch (IOException e) {
	  	System.out.println("Le code unique du membre est incorrect !");
	  	return;
	    }
	    RepertoireClient.getInstance().delete(uid);
	    

	}
	public Membre get_member(int id){
		return RepertoireClient.getInstance().findById(id);
	}
	
	public void getInputValueAndCreateMember(Scanner scanner) {
	    
	    
	    System.out.println("Entrez l'email  du client");
	    String email = scanner.nextLine();
	    

	    String firstName,name,address,city,province;
	    try {
		firstName = Utils.promptStringValuerWithMinAndMaxLength("Entrez le prénom" , 0, 25);
		name = Utils.promptStringValuerWithMinAndMaxLength("Entrez le nom" , 0, 25);
		address = Utils.promptStringValuerWithMinAndMaxLength("Entrez l'addresse du client", 0, 25);
		city = Utils.promptStringValuerWithMinAndMaxLength("Entrez la ville du client", 0, 14);
		province = Utils.promptStringValuerWithMinAndMaxLength("Entre la province du client", 2,2);
		String zip = Utils.promptStringValuerWithMinAndMaxLength("Entrez le code postale du client", 6, 6);
		System.out.println("Entrez le telephone du client");
		String phone = scanner.nextLine();
		
		    
		System.out.println("Payer les frais maintenant ? oui/non");
		String res = scanner.nextLine();
		
		Membre newNember = new Membre(firstName,name,phone,address,email);
		newNember.setCity(city);
		newNember.setProvince(province);
		newNember.setZip_code(zip);
		if(res.equalsIgnoreCase("oui")) {
		    
		    int id =((RepertoireClient) manager).getInstance().generate_id();
		    newNember.setUid(id);
		    newNember.setIs_active(true);
		    System.out.println("votre numero unique est le " + id);
		 }
		
		((RepertoireClient) manager).getInstance().add_member(newNember);
		    
		    
		
	    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
  
	    
	    
	
	    
	 
	        
	        
	    
	}
	public void creeTest() {
	    
	    Membre m = new Membre("Rozi","ALi","33334",	"119 rue charie","rozi.ca");
	    m.setUid(111111111);
	    m.setCity("New York");
	    m.setProvince("NJ");
	    m.setZip_code("123000");
	    System.out.println("numero unique du membre pour les tests : " + m.getUid());
	    m.setIs_active(true);
	    RepertoireClient.getInstance().add_member(m);
	}
	
	
	public void modifyInfosClient(Scanner sc) {
	    
	    
	    
	    int uid;
	    try {
		uid = Utils.promptIntValueWithLength("Entrez le code unique du client", 9);
		
	    } catch (IOException e) {
		System.out.println("Le code unique du membre est incorrect !");
		return;
	    }
	    
	    
	    System.out.println("Entrez la nouvelle addresse/ Laisser vide");
	    String address = sc.nextLine();
	    System.out.println("Entrez le nouveau email / Laisser vide");
	    String email = sc.nextLine();
	    
	    System.out.println("Entrez le nouveau numero de telephone / Laisser vide");
	    String phone = sc.nextLine();
	    Membre m = RepertoireClient.getInstance().findById(uid);
	    if( m != null) {
		RepertoireClient.getInstance().update_member(uid, phone, email, address);
	    }
	    
	    
	}
	
	    /**
	     * Procedure pour permettre a un membre de se logger avec son addresse couriell
	     * @param email
	     * @return le membre avec l'email correspondant au parametre sinon null
	     */
	    public Membre loginMember(String email) {
	        return repository.loginMember(email);
	    }
	
	/**
	 * Methode pour qu'un  membre accede au centre.
	 */
	public void give_acces(Membre m) {
	    
	    int uid;
	    if(m == null) {
		   try {
			uid = Utils.promptIntValueWithLength("Entrez le code unique du client", 9);
			
		    } catch (IOException e) {
			System.out.println("Le code unique du membre est incorrect !");
			return;
		    }
		    m = RepertoireClient.getInstance().findById(uid);
		    if(m == null) {
			System.out.println("Numero du membre incorrect");
			return;
		    }
	    }
	
	
	    if(!m.Is_active()) {
		System.out.println("Membre suspendu : frais impayes");
		return;
	    }
	    System.out.println("VALIDE");
	    System.out.println(m.getFullName() +"\n Numero unique : "
		    + m.getUid()
		    +"\n Code Qr : " + m.getUid());
	    
	    
	    
	}


	public ArrayList<Membre> getAllMember() {
	    return repository.getAllMember();
	}
	

}