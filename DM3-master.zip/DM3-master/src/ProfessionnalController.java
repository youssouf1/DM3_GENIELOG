import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import jdk.javadoc.doclet.Reporter;

public class ProfessionnalController {
	

	private IRepertoire manager;
	
	private static ProfessionnalController single_control;
	
	

	public void create_professionnel(){

		
	}

	public void update_professionnel(String id){

	}

	public void delete_professionnel(String id){

	}
	public Professionnel get_professionnel(String id){
		return null;
	}
	
	public void getNewProf(Scanner scanner) {
	    
	    
	    try {
		    String firstName = Utils.promptStringValuerWithMinAndMaxLength("Entrez le prénom" , 0, 25);
		    String name = Utils.promptStringValuerWithMinAndMaxLength("Entrez le nom" , 0, 25);
		    String address = Utils.promptStringValuerWithMinAndMaxLength("Entrez l'addresse du professionnel", 0, 25);
		    String city = Utils.promptStringValuerWithMinAndMaxLength("Entrez la ville du professionnel", 0, 14);
		    String province = Utils.promptStringValuerWithMinAndMaxLength("Entre la province du professionnel", 2,2);
		    String zip_code = Utils.promptStringValuerWithMinAndMaxLength("Entrez le code postale du professionnel", 6, 6);
		    System.out.println("Entrez l'email  du professionnel");
		    String email = scanner.nextLine();
		  
		    System.out.println("Entrez le telephone du professionnel");
		    String phone = scanner.nextLine();
		    
		   
		    
		    System.out.println("Entrez l'occupation du professionnel");
		    String occ = scanner.nextLine();
		    Professionnel p = new Professionnel(firstName,name,phone,address,city,province,zip_code,email);
		    p.setOccupation(occ);
		    
		    RepertoireProfessionnel.getInstance();
		    int uid = RepertoireProfessionnel.generateUid();
		    p.setUid(uid);
		    RepertoireProfessionnel.getInstance().add_professionnel(p);
		    System.out.println("*******************************************************************");
		    System.out.println("Votre compte a ete cree, votre identifiant unique est le " 
			    + p.getUid());
		    System.out.println("*******************************************************************");
	    }
	    catch(Exception e) {
		
	    }
	
	    
	    
	    
	}
	
	public void modifyInfosClient(Scanner sc) {
	    
	    int uid;
	    try {
		uid = Utils.promptIntValueWithLength("Entrez le code unique du client", 9);
		
	    } catch (IOException e) {
		System.out.println("Le code unique du membre est incorrect !");
		return;
	    }
	    
	    System.out.println("Entrez la nouvelle addresse/ Laisser vide");
	    String address = sc.nextLine();
	    System.out.println("Entrez le nouveau email / Laisser vide");
	    String email = sc.nextLine();
	    
	    System.out.println("Entrez le nouveau numero de telephone / Laisser vide");
	    String phone = sc.nextLine();
	    Professionnel m = RepertoireProfessionnel.getInstance().findById(uid);
	    if( m != null) {
		RepertoireProfessionnel.getInstance().update_professionnel(uid, phone, email, address);
	    }
	    
	    
	}
	    /**
	     * Procedure pour permettre a un membre de se logger avec son addresse couriell
	     * @param email
	     * @return le membre avec l'email correspondant au parametre sinon null
	     */
	    public Professionnel loginProf(String email) {
	        return RepertoireProfessionnel.getInstance().loginProf(email);
	    }
	
	public static ProfessionnalController getInstance() {
	    // TODO Auto-generated method stub
	    return (single_control == null)? new ProfessionnalController() : single_control;
	}
	
	public Professionnel getProfessionnel(int uid) {
	    return RepertoireProfessionnel.getInstance().findById(uid);
	}
	
	public ArrayList<Professionnel> getAllProfs(){
	    return RepertoireProfessionnel.getInstance().getAllProfs();
	}

	public void test() {
	   RepertoireProfessionnel.getInstance().add_one();
	    
	}
}