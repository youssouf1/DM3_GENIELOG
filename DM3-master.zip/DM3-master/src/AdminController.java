import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;



public class AdminController {

	private IRepertoire manager;

	private static AdminController admin;
	
	private static final String Prof_rapport_dir = "RapportProfessionnel";
	private static final String Member_rapport_dir = "RapportMembre";
	/**
	 * Utiliser une seule instance de cette classe
	 * @return
	 */
	public static AdminController getInstance() {
	    return (admin == null) ? new AdminController(): admin;
	}
	
	public AdminController() {
	    
	    File dirRapport = new File(Prof_rapport_dir);
	    dirRapport.mkdir();
	    File dir2 = new File(Member_rapport_dir);
	    dir2.mkdir();
	    
	    
	}
	
	/**
	 * La generation du rapport 
	 */
	public void generate_rapport(ProfessionnalController prof_control, ServiceController services) {
	    
	    /*
	     * La procédure comptable lit aussi le fichier des services fournis de la semaine et produit 
	     * un rapport de synthèse qui est envoyé au gérant. Ce rapport peut aussi être exécuté 
	     * individuellement à la demande du gérant de #GYM à n'importe quel moment de la semaine. 
	     * Le rapport concerne les comptes payables et décrit la liste de tous les professionnels qui 
	     * doivent être payés cette semaine-là, le nombre de services de chacun et le total de leurs 
	     * frais pour cette semaine-là. À la fin du rapport, le nombre total de professionnels qui ont 
	     * fourni des services cette semaine-là, le nombre total de services et le total des frais doivent 
	     * apparaitre.
	     */
	    
	    ArrayList<Professionnel> tab_prof = prof_control.getAllProfs();
	    System.out.println("Rapport généré(-s): \n");
	    System.out.println("Le nom du professionnel Le numero du professionnel  Montant a transferer  Nombre de service");
	    double due = 0;
	    int prof_active = 0;
	    int service_total = 0;
	    for(Professionnel prof : tab_prof) {
		
		 System.out.print(prof.getFullName() );
		 String msg="";
		 ArrayList<Service> prof_service = services.getProfsService(prof.getUid());
		 double total = 0;
		 for( Service service1 : prof_service) {
		     total += service1.getFees() * service1.getTotalInscript();
		 }
		// if(total == 0 ) continue;
		 due += total;
		 prof_active++;
		 service_total++;
		if(prof.getFullName().length() < 30) {
		    int space = 32-  prof.getFullName().length();
		   
		    for(int i =0; i < space ; i++) {
			msg += " ";
		    }
		}
		System.out.print(msg +" ");
		
		 System.out.print(prof.getUid() +"                 ");
	
		 
		 System.out.println( total +"$             " + prof_service.size());
		
	    }
	    
	    System.out.println("le nombre total de professionnels qui ont fourni des services : " + prof_active);
	    System.out.println("le nombre total de services :" + service_total );
	    System.out.println("Total des frais  à payer :" + due +"$");
	   
	}
	
	 public static void generateReportMembres() {
	       
	     
	     ArrayList<Membre> all_member = MemberController.getInstace().getAllMember();
	     
	     for(Membre m : all_member) {
		 
		 
		 String msg = m.toString()+"\n";
		 
		 ArrayList<Service> member_course = ServiceController.getInstance().getMemberSeanceSuivi(m.getUid());
		 
		 for (Service c : member_course) {
		     
		     msg += c.getStart_date() +"\n" + 
		     ProfessionnalController.getInstance().getProfessionnel(c.getProf_num()).getFullName() +"\n"
		     + c.getName();
		 }
		 
		try {
		    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		   String date = formatter.format(new Date());
		    BufferedWriter bf = new BufferedWriter(new 
		    	FileWriter(Member_rapport_dir +"/" + m.getFirstName() + m.getLastName() +date));
		    bf.write(msg);
		    bf.flush();
		    
		} catch (IOException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
	     }
	     System.out.println("rapport des membres generes et sont disponibles dans le repertoire du rapport");
	 }
	    
	
	public static void generateFactureProf()  {
	    System.out.println("\n\nFactures prof:");
	    
	    ArrayList<Professionnel> all_profs = RepertoireProfessionnel.getInstance().getAllProfs();
	  
	    for (Professionnel prof :all_profs) {
		String msg = "";
		
		int total_pay = 0, num =0;
		ArrayList<Service> prof_service = ServiceController.getInstance().getProfsService(prof.getUid());
	        if(prof_service.size() == 0 ) continue;
	        
	        try{
	            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	            String date = formatter.format(new Date());
	            BufferedWriter bf = new  BufferedWriter(new FileWriter(Prof_rapport_dir+"/" + prof.getFirstName()+
	        	    prof.getLastName()  + date));
	            
	            msg += prof.toString() +"\n";
		        for (Service c : prof_service) {
		            
		            for( Membre m  : c.getAllMember()) {
		        	msg += m.getFullName() +", " + m.getUid()
		        	+" , " + c.getService_code() +" , " + c.getFees() +"\n";
		        	total_pay += c.getFees();
		            }
		            num++;
		        }
		        msg += "Nombre total de consultations " + num +"\n"
				    + "total des frais :" + total_pay +"\n";
		       
		       bf.write(msg);
		       bf.flush();
	        } catch(Exception e) {};
	        
	     }
	   
	    System.out.println("rapport des professionnels generes et sont disponibles dans le repertoire du rapport");

	    }

	/**
	 * Procedure pour generer le TEF
	 * 		 */
	public void generate_TEF(ProfessionnalController prof_control, ServiceController services){
	    
	    // avoir la listes de tous les profs;
	    ArrayList<Professionnel> tab_prof = prof_control.getAllProfs();
	    System.out.println("TEF généré(-s): \n");
	    System.out.println("Le nonm du professionnel\t Le numero du professionnel \t Montant a transferer");
	    for(Professionnel prof : tab_prof) {
		
		 System.out.print(prof.getFullName() );
		 String msg="";
		if(prof.getFullName().length() < 30) {
		    int space = 32-  prof.getFullName().length();
		   
		    for(int i =0; i < space ; i++) {
			msg += " ";
		    }
		}
		System.out.print(msg +"\t");
		
		 System.out.print(prof.getUid() +"                 \t");
		 ArrayList<Service> prof_service = services.getProfsService(prof.getUid());
		 double total = 0;
		 for( Service service1 : prof_service) {
		     total += service1.getFees() * service1.getTotalInscript();
		 }
		 System.out.println( total +"$" +"\n");
		 
		 generateFactureProf();
		 generateReportMembres();
		
	    }
	    
	     
	}
	
	
	   
	    
	    
}