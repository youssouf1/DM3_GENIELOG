public interface IRepertoire {

	IRepertoire create_new();

	void modify_data();

	boolean delete_one();

}