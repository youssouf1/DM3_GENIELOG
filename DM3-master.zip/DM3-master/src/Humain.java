import java.util.ArrayList;
import java.util.Date;

public abstract class Humain {

	private String firstName;
	private String lastName;
	private Date birthday;
	private String email;
	private String phone;
	private String addresse;
	
	private String city;
	
	private String province;
	private String zip_code;
	
	
	
	private int uid;

	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	/**
	 * 
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthday() {
		return this.birthday;
	}

	/**
	 * 
	 * @param birthday
	 */
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getAddresse() {
		return this.addresse;
	}

	/**
	 * 
	 * @param attribute
	 */
	public void setAddresse(String attribute) {
		this.addresse = attribute;
	}

	public String getEmail() {
		return this.email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	public int getUid() {
	    return uid;
	}

	public void setUid(int uid) {
	    this.uid = uid;
	}

	public String getPhone() {
	    return phone;
	}

	public void setPhone(String phone) {
	    this.phone = phone;
	}
	
	
	public String getFullName() {
	    
	    return this.firstName +" " + lastName;
	}
	public Humain (String firstName, String lastName, String phone, String address,
		String email) {
	    this.firstName = firstName;
	    this.lastName = lastName;
	    this.phone = phone;
	    this.addresse = address;
	    this.email = email;
	    
	}
	
	
	public Humain(String firstName, String lastName, String phone, String address,
		String city, String province, String zip_code,
		String email) {
	    
	    this(firstName,  lastName,  phone,  address,email);
	    this.city = city;
	    this.province = province;
	    this.zip_code = zip_code;
	    
	    
	}
	
	
	public Humain() {}

	public String getCity() {
	    return city;
	}

	public void setCity(String city) {
	    this.city = city;
	}

	public String getProvince() {
	    return province;
	}

	public void setProvince(String province) {
	    this.province = province;
	}

	public String getZip_code() {
	    return zip_code;
	}

	public void setZip_code(String zip_code) {
	    this.zip_code = zip_code;
	};
	
	public String toString() {
	  
	    return getFullName() +"\n" +
		    uid +"\n" +
		   addresse +"\n"+
		   city +"\n"+
		   province +"\n" +
		   zip_code;
	    
	    
	}
	
	

}