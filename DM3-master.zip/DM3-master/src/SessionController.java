public class SessionController implements IRepertoire{


    	private static SessionController controller;
    	
    	public static SessionController getInstance() {
    	    return (controller == null) ? new SessionController() : controller;
    	}
	public void subscribe(ServiceController scon,Membre curr){
	    new Inscription(scon).subscribe(curr);
	    
	}
	public void confirm_subscription(ServiceController scon, Membre b){
	    new Inscription(scon).confirm(b);
	}

	public IRepertoire create_new() {
	    return null;
	};

	public void modify_data() {
	    
	};

	public boolean delete_one() {
	    return false;
	};

	

}