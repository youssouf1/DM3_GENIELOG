public class ClientView extends View{
	


	public void print_menu() {
	    
	    
	}
	
	
	

}