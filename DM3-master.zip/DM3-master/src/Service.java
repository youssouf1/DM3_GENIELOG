import java.util.ArrayList;
import java.util.Date;

public class Service {

	private String name;
	private String start_date;
	private String end_date;
	private String start_hour;
	private double price;
	private int max_capacity;
	
	private  ArrayList<String> dayInWeeks = new ArrayList<>();
	private  ArrayList<Membre> inscriptions = new ArrayList<Membre>();
	private String comment = "";
	private double fees;
	private int prof_num;
	private String recurrence;
	
	private String date_creation;
	private int service_code;
	public String getComment() {
	    return comment;
	}
	public void setComment(String comment) {
	    this.comment = comment;
	}
	public int getProf_num() {
	    return prof_num;
	}
	public void setProf_num(int prof_num) {
	    this.prof_num = prof_num;
	}
	public String getRecurrence() {
	    return recurrence;
	}
	public void setRecurrence(String recurrence) {
	    this.recurrence = recurrence;
	}
	public int getService_code() {
	    return service_code;
	}
	public void setService_code(int service_code) {
	    this.service_code = service_code;
	}
	public String getName() {
	    return name;
	}
	public void setName(String name) {
	    this.name = name;
	}
	public String getStart_date() {
	    return start_date;
	}
	public void setStart_date(String start_date) {
	    this.start_date = start_date;
	}
	public int getMax_capacity() {
	    return max_capacity;
	}
	public void setMax_capacity(int max_capacity) {
	    this.max_capacity = max_capacity;
	}
	public double getPrice() {
	    return price;
	}
	public void setPrice(double price) {
	    this.price = price;
	}
	public String getStart_hour() {
	    return start_hour;
	}
	public void setStart_hour(String start_hour) {
	    this.start_hour = start_hour;
	}
	public String getEnd_date() {
	    return end_date;
	}
	public void setEnd_date(String end_date) {
	    this.end_date = end_date;
	}
	
	
	public Service (String debut, String end, String startingTime,
	                   String recc, int maxCapacity, int professionalNumber,
	                    int serviceCode, String comment, int fees) 
	{
	        this.start_date = debut;
	        this.end_date = end;
	        this.start_hour = startingTime;
	        this.recurrence = recc;
	        this.max_capacity = maxCapacity;
	        this.prof_num = professionalNumber;
	        this.service_code = serviceCode;
	        this.comment = comment;
	        this.setFees(fees);
	}
	
	    public Service() {
	    // TODO Auto-generated constructor stub
	}
	   
	    @Override
	    public String toString() {
		String day = "\nJours pendant la semaine de la seance: ";
		for (String d : dayInWeeks) {
		    day +=  d +" ,";
		}
	        String result = 
	        	" Date de création : " + date_creation+
	        	
	        	"\n Date de début : " + start_date +
	                "\n Date de fin : " + end_date +
	                "\n Heure de début : " + start_hour +
	                day +
	                "\n Recurrence hebdomadaire : " + recurrence +
	                "\n Capacité maximal : " + max_capacity +
	                "\n Numéro du professionnel " + prof_num +
	                "\n Code du service " + service_code +
	        	"\n frais pour service : " + fees +"$" ;
	        if (!comment.equals("")) result += "\n Commentaire : " + comment;
	        return result;
	    }
	    public double getFees() {
		return fees;
	    }
	    public void setFees(double fees) {
		this.fees = fees;
	    }
	    public String getDate_creation() {
		return date_creation;
	    }
	    public void setDate_creation(String date_creation) {
		this.date_creation = date_creation;
	    }
	    public ArrayList<String> getDayInWeeks() {
		return dayInWeeks;
	    }
	    public void setDayInWeeks(ArrayList<String> dayInWeeks) {
		this.dayInWeeks = dayInWeeks;
	    }
	    public void addMemberToSeance(Membre m) {
		    inscriptions.add(m);
	    }
	    
		
		public void deleteMemberFromSeance(int uid) {
		    int i =0;
		    for(Membre m : inscriptions) {
			
			if (m.getUid() == uid) {
			    inscriptions.remove(i);
			    break;
			    
			}
			i++;
			    
		    }
		}
		public void inscrireMembre(Membre m) {
		    inscriptions.add(m);
		  
		}
		
		public void print_all_inscripts() {
		    if(inscriptions.size() == 0 ) {
			System.out.println("Aucun inscript a cette seance.");
			return;
		    }
		    System.out.println("La listes des inscrits pour la seance de " + this.name);
		    int index = 0;
		    for(Membre m : inscriptions) {
			System.out.println(index +" . " + m.getFullName());
		    }
		}
		
		/**
		 * methode pour determiner si un membre est inscrit a une seance
		 */
		
		public boolean est_inscrire(int codeMember) {
		    for(Membre m : inscriptions) {
			
			if(m.getUid() == codeMember )
			    return true;
		    }
		    return false;
		}
	
	
		public ArrayList<Membre> getAllMember(){
		    return inscriptions;
		}
		public int getTotalInscript() {
		   
		    return inscriptions.size();
		}
	

}