import java.util.ArrayList;

public class RepertoireProfessionnel implements IRepertoire {

	private static ArrayList<Professionnel> map = new ArrayList<>();

	private static RepertoireProfessionnel single_prof ;
	public static RepertoireProfessionnel getInstance() {
	    
	    
	    return (single_prof ==null) ? new RepertoireProfessionnel() : single_prof;
	}
	public void add_professionnel(Professionnel p){
	    map.add(p);
	    
	   
	}

	public void add_one() {
	    
	    Professionnel p = new Professionnel("Pierre", "Dupont", "4543456", "113 rue 34", "rozi");
	    p.setCity("Montreal");
	    p.setProvince("QC");
	    p.setZip_code("H4H2J2");
	    getInstance();
	    p.setUid(RepertoireProfessionnel.generateUid());
	    System.out.println("numero unique du professionnel pour les tests : " + p.getUid());
	    
	    map.add(p);
	}

	
	public boolean delete(int id) {
	     int j = -1;

	     for (int i = 0; i < map.size(); i++) {
		 if (map.get(i).getUid() == id) {
	               j = i;
	                break;
		 }
	     }

	        if (j >= 0) {
	            map.remove(j);
	        }
	        return j >= 0;
	}


	
	public IRepertoire create_new(){
	    
	    
	    return null;
	}

	public void modify_data(){}

	public boolean delete_one(){
	    
	    
	    return false;
	}
	
	
	    /**
	     * Cible un professionnel en particulier
	     * @param id
	     * @return le professionnel s'il existe sinon null
	     */
	    public Professionnel findById(int id) {
	        Professionnel result = null;
	        for (int i = 0; i < map.size(); i++) {
	            if (map.get(i).getUid() == id) {
	                result = map.get(i);
	                break;
	            }
	        }
	        return result;
	    }
	    public void update_professionnel(int uid, String phone, String email, String address) {
		Professionnel p = findById(uid);
		if(p == null) return;
		   
		    if(phone.length() > 0 ) {
			p.setPhone(phone);
		    }
		    if(email.length() > 0) {
			p.setEmail(email);
		    }
		    
		    if(address.length() > 0) {
			p.setAddresse(address);
		    }
		
	    }
	    
	   /**
	    * Procedure pour generer des ids
	    * @return
	    */
		
		
		public static int generateUid() {
		    
		    boolean uniq  = true;
		    int rand;
		    
		    do {
			rand = (int) (Math.floor(Math.random() * 1000000000 )+ 45);
			for (Humain p : map) {
			    if (p.getUid() == rand) {
				uniq = false;
				break;
			    }
			}
		    } while ( !uniq && ((""+rand).length() != 9));
		  
		    return rand;
		}
		
	    /**
	     * Retourne la liste de tous les professionnels
	     * @return
	     */
	    public ArrayList<Professionnel> getAllProfs() {
		return map;
	    }
	    public Professionnel loginProf(String email) {
		
		for (int i = 0; i < map.size(); i++) {
	            if (map.get(i).getEmail().contentEquals(email)) {
	                return  map .get(i);
	            }
	        }
	        return null;
	    }
}