public class Subscription{
	

	private Membre curr_member;
	private String date_creation;
	private String date_start;
	private boolean is_confirmed;
	private String comments;

	
}