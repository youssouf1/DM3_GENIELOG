import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

class Test {

    
    
    /**
     * Tester si un membre qui vient de s'inscrire
     * si son compte est active ou non.
     */
    @org.junit.jupiter.api.Test
    void testMemberActivation() {
	
	Membre m = new Membre("Alain","Marc","5145653","11 rue montreal 01","alain.marc@ca");
	
	assertTrue("Le membre n'est pas active",! m.Is_active());
    }
    
    
    /**
     * 
     * Tester si les 2 derniers chiffres du code d'une seance 
     * est egale au 2 derniers chiffres du numero de 
     * professionnel
     */
    @org.junit.jupiter.api.Test
    void testSeanceCodeLast2Digit() {
	
	
	
	    Service c = new Service();
	    int profNum = 987654321;
	    c.setDate_creation("06-08-2020 02:45:21");
	    c.setEnd_date("12-12-2020");
	    c.setStart_date("06-08-2020");
	    c.setFees(56.76);
	    ArrayList<String> dayInWeeks = new ArrayList<String>();
	    dayInWeeks.add("THURSDAY");
	    c.setDayInWeeks(dayInWeeks);
	    c.setMax_capacity(23);
	    c.setName("Tennis");
	    c.setStart_hour("12:45");
	    c.setProf_num(987654321);
	    c.setRecurrence("1");
	    c.setService_code(ServiceController.getInstance().generateSeanceCode(profNum, "123")); // 123 34 5
	    String last2digit = (c.getService_code()+"").substring(5);
	    String proflast2digit = (profNum+"").substring(7);
	    
	    assertEquals("Les 2 derniers chiffres du code de la service", last2digit, proflast2digit);
	        
    }
    
    @org.junit.jupiter.api.Test
    
    /**
     * Tester si la longueur du numero de seance 
     * d'un membre est egale a 9.
     */
    void testMemberUIDLength() {
	
	Membre member = new Membre("Jean", "Beaulieu", "34567654", "112 rue ndg", "jean@beaulieu.ca");
	
	member.setUid(RepertoireClient.generateUid());

	int length = (member.getUid()+"").length();
	
	assertEquals("La longueur du numero de membre n'est pas egale a 9", length,9);
	
    }
    
    
    @org.junit.jupiter.api.Test
    /**
     * Tester la mise a jour du nombre de service
     * disponible dans le centre de donnees.
     */
    void testSeanceData() {
	
	ServiceController.getInstance().test();
	
	int service_total = ServiceController.getInstance().getServiceTotal();
	
	assertNotEquals(service_total, 0,"Le service n'est pas ajouter a la base de donnees : " );
    }
    
    
    @org.junit.jupiter.api.Test
    /**
     * Tester la mise a jour de l'addresse courriel d'un membre
     */
    void testMemberChangement() {
	Membre member = new Membre("Jean", "Beaulieu", "34567654", "112 rue ndg", "jean@beaulieu.ca");
	member.setCity("New York");
	RepertoireClient.getInstance().add_member(member);
	member.setCity("Montreal");
	String new_email = "jean2@yahoo.ca";
	RepertoireClient.getInstance().update_member(member.getUid(),"",new_email,"");
	String member_email = RepertoireClient.getInstance().findById(member.getUid()).getEmail();
	assertEquals("L'addresse email n'est pas a jour",member_email,new_email);
    }
    
    
    
    /**
     * Tester la longeur du code de service de toute 
     * la base de donner si c'est egale a 7 ou pas.
     */
    @org.junit.jupiter.api.Test
    void testerServiceCodeSeanceLength() {
	
	ServiceController.getInstance().test();
	ArrayList<Service> tab_service = ServiceController.getInstance().getAllService();
	for(Service c : tab_service) {
	    assertEquals("La longuer du code du service n'est pas 7",(c.getService_code()+"").length(),7); 
	}
	
    }
    
    
    

}
