

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtils {
    private static final String FORMAT_DATE = "dd-MM-yyyy";
    private static final String FORMAT_HOURS = "HH-MM";
    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_DATE);

    public static String getDateInput(String message) throws IOException {
	
        String s = verifyDateFormat(message);
     
        return s;
    }
    
    
    public static String getDateInputOrNull(String md) throws IOException {
	
	if(md.equalsIgnoreCase("non")) {
	    return md;
	}
	
	return getDateInput(md);
    }
    
  
    public static boolean isToday(Date date) {
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(date);
        cal2.setTime(new Date());
        boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
                cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
        return sameDay;
    }

    public static String dateFormatted(Date date) {
        return simpleDateFormat.format(date);
    }

    public static String verifyDateFormat(String message) throws IOException {
        String datePattern = "^([0-2][0-9]|(3)[0-1])-(((0)[0-9])|((1)[0-2]))-\\d{4}$";
        Pattern pattern = Pattern.compile(datePattern);
        return verify(message, pattern, FORMAT_DATE);
    }

    public static String verifyHoursFormat(String message) throws IOException {
        Pattern pattern = Pattern.compile("^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$");
        return verify(message, pattern, FORMAT_HOURS);
    }

    public static String verify(String message, Pattern pattern, String format) throws IOException {
        Matcher m;
        String s;
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int counter = 0;

        do {
            System.out.println(message);
            if (counter++ > 0) {
                System.out.println("Erreur: format n'a pas été bon, veuillez répéter");
                System.out.println("Format désiré: " + format);
            }
            s = reader.readLine();
            if (s.equals("non")) return s;
            m = pattern.matcher(s);

        } while (!m.find());
        return s;
    }
}
