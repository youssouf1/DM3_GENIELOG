import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Session{
	

	private String day;
	private String schedule;
	
	
	
	public Session() {
	    this.day = getDay();
	}
	
	public String getDay() {
	    
	    Calendar calendar = Calendar.getInstance();
	    Date date = (Date) calendar.getTime();
	    String day = new SimpleDateFormat("EEEE", Locale.ENGLISH).format(date.getTime());

	    return day;
	}
	
	
	
	
}