
import java.io.IOException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;


public class Main{
	public static int menu = 0;
	
	private static String msg_retour = "retour au menu principal";
	public static Scanner navigation = new Scanner(System.in);
	public static boolean close = true;
	
	public static MemberController member_controller = MemberController.getInstace();
	
	public static ProfessionnalController prof_controller = ProfessionnalController.getInstance();
	
	public static ServiceController service_control = ServiceController.getInstance();
	public static SessionController session_contol = SessionController.getInstance();
	private static AdminController admin = AdminController.getInstance();
	
	private SimpleDateFormat format_date = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
    
	public static void menu_client(){
		menu = 1;
		
		String input = "";
		while (true) {
		    System.out.println("Choisissez une des options suivantes: ");         
		    System.out.println("1 - Créer un compte"); 
		    System.out.println("2 - Mise a jour des informations du membre");
		    System.out.println("3 - Supprimer un membre");
		    System.out.println("4 - Acces au centre");         
		  //  System.out.println("5 - Confirmation de présence");   
		    System.out.println("6 - Inscription à une séance"); 
		    System.out.println("7 - afficher les informations du client");
		    System.out.println("0 - " + msg_retour);
		    
		    input = navigation.nextLine();
		    
		    switch(input) {
		    
        		    case "1" : member_controller.getInputValueAndCreateMember(navigation);
        		    break;	
        		    case "2" : member_controller.modifyInfosClient(navigation); break;	
        		    case "3" : member_controller.delete_member();; break;	
        		    case "4" : member_controller.give_acces(null); break;	
        		    //case "5" : session_contol.confirm_subscription(service_control);; break;	
        		    case "6" : session_contol.subscribe(service_control,null); break;
        		    case "7" : {
        			
        			int code;
				try {
				    code = Utils.promptIntValueWithLength("Entrez le numero unique du membre", 9);
				    Membre c = member_controller.get_member(code);
				    if( c == null) System.out.println("membre inexistant");
				    System.out.println(c);
				} catch (IOException e) {
				    // TODO Auto-generated catch block
				    e.printStackTrace();
				}
        			
        		    } break;
        		    case "0" : return;
		    
		    }
		    System.out.println(" ");
		    
		}
	};
	
	
	public static void menu_professionnel(){
		menu = 2;
		String input = "";
		do {
		    System.out.println("Choisissez une des options suivantes: ");         
		    System.out.println("1 - Fournir un service");         
		    System.out.println("2 - Consulter la liste des inscrits"); 
		    System.out.println("3 - Créer un compte");  
		    System.out.println("4 - modifier un service");
		    System.out.println("5 - supprimer un service");
		    System.out.println("6 - acces au centre");
		    System.out.println("0 - " + msg_retour);
		    
		    input = navigation.nextLine();
		    
		    switch(input) {
		    
        		    case "1" :try {
        			
        			
			    service_control.create_service(prof_controller);
			} catch (IOException e) {
			 
			   
			}
        		    break;	
        		    case "2" :service_control.display_inscrits(null) ; break;	
        		    case "3" : prof_controller.getNewProf(navigation); break;
        		    case "4" : service_control.update_service(); break;
        		    case "5" : try {
			    service_control.delete_service();
			} catch (IOException e) {
			   
			} break;
        		    case "6" : member_controller.give_acces(null);
        		    case "0" :  return;
		    
		    }
		    
		} while (true);
		 
	};

	public static void inscription_seance(){

	};

	
	
	public static void appli_menu() {
	    System.out.println("Bienvenue au #GYM Mobile");
	    String answer = "";
	    do {
		  System.out.println("Vous etes un");
		  System.out.println("1 - Membre");
		  System.out.println("2 - Professionnel");
		  answer = navigation.nextLine();
	    } while( !(answer.equalsIgnoreCase("1") || answer.equalsIgnoreCase("2")));
	  
	    
	   
	    switch(answer) {
	    
	    case "1" : menu_mobile_client(); break;
	    case "2" : menu_mobile_prof(); break;
	    default : System.out.println("Entree incorrecte."); return;
	    }
	}
	
	private static void menu_mobile_client() {
	    
	    
	    try {
		String email = Utils.promptStringValuerWithMinAndMaxLength("Entrez votre adresse email", 0, 1000);
		
		Membre current_member = member_controller.loginMember(email);
		
		if(current_member == null) {
		    System.out.println("Membre inexistant ");
		    return;
		}
	
		
		for(int i =0; i < 45 ; i++) System.out.print("#");
		System.out.print("\nBienvenue Mr : " + current_member.getFirstName() +"\n \n \n");
		for(int i =0; i < 45 ; i++) System.out.print("#");
		System.out.println();
		
		  
			System.out.println("choississez une option");
			System.out.println("1 - Acces au centre");         
			System.out.println("2 - Inscription à une séance"); 
			System.out.println("0 - se deconnecter et " + msg_retour);
			String res = navigation.nextLine();
			switch(res) {
			case "1" : member_controller.give_acces(current_member); break;
			case "2" : session_contol.subscribe(service_control, current_member); break;
			case "0" : return;
			}
			
		  
		
	    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	    
	}

	/**
	 * Menu pour l'application mobile 
	 * du professionnel
	 * @throws IOException 
	 */
	private static void menu_mobile_prof() {
	    try {
		String email = Utils.promptStringValuerWithMinAndMaxLength("Entrez votre adresse email", 0, 1000);
		
		Professionnel curr = prof_controller.loginProf(email);
		if(curr == null) {
		    System.out.println("connexion non etablie, reessayer plus tard");
		    return;
		}

		for(int i =0; i < 45 ; i++) System.out.print("#");
		System.out.print("\nBienvenue Mr : " + curr.getFirstName() +"\n \n \n");
		for(int i =0; i < 45 ; i++) System.out.print("#");
		System.out.println();
		System.out.println("Choisir une option");
		System.out.println("1 - Consulter les inscrits");
		System.out.println("2 - Confirmer la présénce d'un membre");
		System.out.println("0 - se deconnecter et " + msg_retour);
		
		String res = navigation.nextLine();
		switch(res) {
		
			case "1" : service_control.display_inscrits(curr); break;
			case "2" : session_contol.confirm_subscription(service_control, null); break;
			case "0" : return;
			
		}
		
	    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	    
	    
	}
	
	public static void menu_principal() {	        
		menu = 0; 
		System.out.println("Choisissez une des options suivantes: ");    
		System.out.println("1 - #GYM_MOBILE: application mobile");
		System.out.println("2 - Menu client");         
		System.out.println("3 - Menu professionnel");
		System.out.println("4 - Lancez la procédure comptable (il est minuit)");
		System.out.println("5 - generer le rapport du gerant");
		
		System.out.println("0 - Quitter");
		
	};
	
	public static void main(String[] args){
		
		String instruction;
		
		prof_controller.test();
		service_control.test();
		member_controller.creeTest();
		do {
		  
		    menu_principal();
		    
		    instruction = navigation.nextLine();
		    switch(instruction){
		    	case "1" : appli_menu(); break;
			case "2": menu_client();break;
			case "3": menu_professionnel();break;
			case "4" : admin.generate_TEF(prof_controller, service_control); break;
			case "5" : admin.generate_rapport(prof_controller, service_control); break;
			case "0": close = false;
		    }
		    
		} while (close);
		
		navigation.close();
		
	}
	
	
};