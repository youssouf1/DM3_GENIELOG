public abstract class View{
	
	
	public void display_message(String m){


	}

	public String getInput(){
		return "";
	} 

	public void print_menu() {
	    
	};

	



}