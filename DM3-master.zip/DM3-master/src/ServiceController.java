import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;



public class ServiceController {


	private IRepertoire manager;
	
	private static ServiceController single;
	
	private RepertoireService repository = RepertoireService.getInstance();
	private ArrayList<String> code_seanceT = new ArrayList<String>();
	
	
	/**
	 * Retourne le numero associer au
	 * nom d'une activite physique
	 * @param code
	 * @return
	 */
	public String getName(String code) {
	    switch(code) {
	    
	    case "123" : return "Basket";
	    case "233" : return "Soccer";
	    case "355" : return "Tennis";
	    
	    case "476" : return " Entraineur personnel";
	    case "511" : return "Yoga";
	    case "666" : return "Tennis";
	    
	    case "700" : return "Nutritionnist";
	    case "890" : return "Physiothérapeute";
	    case "990" : return "Massothérapeute";
	    default : return "";
	    
	    }
	 
	}
	
	private void make_init_tab() {
	    code_seanceT.add("123");code_seanceT.add("233");
	    code_seanceT.add("355"); code_seanceT.add("476");
	    code_seanceT.add("511"); code_seanceT.add("666");
	    code_seanceT.add("700"); code_seanceT.add("890");
	    code_seanceT.add("990");
	}
	
	
	public ServiceController() {
	    make_init_tab();
	}
	/**
	 * Afficher l'ensembles des activites pour le centre gym
	 */
	public void display_activity() {
	    System.out.println("123 - Basket");
	    System.out.println("233 - Soccer");
	    System.out.println("355 - Tennis");
		    
	    System.out.println("476 - Entraineur personnel");
	    System.out.println("511 - Yoga");
	    System.out.println("666 - Cross-fit");
	    
	    System.out.println("700 - Nutritionniste");
	    System.out.println("890 - Physiothérapeute");
	    System.out.println("990 - Massothérapeute");
	}
	
	/**
	 * Choisir une activites physiques
	 * @return
	 */
	public String choose_activity() {
	    Scanner sc = new Scanner(System.in);
	    String input = "";
	    int p;
	    do {
		System.out.println("choisir le code de la seance");
		display_activity(); 
		input = sc.nextLine();
		p =Utils.tryParse(input);
		
	    } while(!code_seanceT.contains(input));
	    
	    return input;
	    
	    
	    
	}
	/**
	 * Choisir les jours de l'occurrence d'une service
	 * pendant la semaine
	 * @return
	 */
	public ArrayList<String> choose_day() {
	    String res ="";
	    Scanner sc = new Scanner(System.in);
	  
	    while(res.equals("")) {  
		System.out.println("Veuillez choisir les jours pour la seance du service"
		    	+ "separez par un espace blanc pour plusieurs jours comme 1 2 veut dire"
		    	+ "Lundi et Mardi");
		   System.out.println("1 .Monday");
		   System.out.println("2 .Tuesday");
		   System.out.println("3 .Wednesday");
		   System.out.println("4 .Thursday");
		   System.out.println("5 .Friday");
		   System.out.println("6 .Saturday");
		   System.out.println("7 .Sunday");
		   res = sc.nextLine();
	    }
	    String[] splited = res.split("\\s");
	    ArrayList<String> days = new ArrayList<>();
	    for(int i =0; i < splited.length; i++) {
		days.add(getDayName(splited[i]));
	    }
	    return days;
	 
	}
	
	public String getDayName(String num) {
	    switch(num) {
	    
	    case "1" : return "MONDAY";
	    case "2" : return "TUESDAY";
	    case "3" : return "WEDNESDAY";
	    case "4" : return "THURSDAY";
	    case "5" : return "FRIDAY";
	    case "6" : return "SATURDAY";
	    case "7" : return "SUNDAY";
	    default : return "";
	   
	    }
	}
	/**
	 * Procedure pour la creation d'un nouveau service.
	 * @param p
	 * @throws IOException
	 */
	public void create_service(ProfessionnalController p ) throws IOException{
	    
	    
	    String name = choose_activity();
	   
	    String debut = DateUtils.getDateInput("Entrez date de début du service. en format JJ-MM-AAAA");
	   
	    String end = DateUtils.getDateInput("Entrez date de fin du service en format JJ-MM-AAAA" );
	   
	    String hours = DateUtils.verifyHoursFormat("Entrez heure du services en format HH:MM" );
	    ArrayList<String> days = choose_day();
	        
	    String recc = Utils.promptStringValuerWithMinAndMaxLength("Entrez récurrence hebdomadaire du service", 1, 1000);
	    
	    int capacity = Utils.promptIntValueWithUpperBond("Entrez le nombre de capacité maximale du service" , 30);
	      
	    int profNumber = -1;
	    int counter = 0;
	    
	    do {
		
			if(counter == 3) {
			    System.out.println("Veuillez creer un compte pour pouvoir fournir un servir");
			    return;
			}
	            if (counter > 0) System.out.println("Le professionnel avec id " + profNumber + " n'est pas trouvé");
	            profNumber = Utils.promptIntValueWithLength("Entrez numéro du professionnel tentative (" + counter +"/ 3)", 9);
	            counter++;
	    } while (p.getProfessionnel(profNumber) == null );
	      
	    int fees = Utils.promptIntValueWithUpperBond("Entrez les frais du service", 100);
	   
	    String comment = Utils.promptStringValuerWithMinAndMaxLength("Entrez commentaires (max 100 charactèrs) ou laissez le champ vide", 0, 100);
	    int code = getNewServiceCode(profNumber, name);
	    Service c = new Service(debut, end, hours, recc, capacity, profNumber,code, comment, fees);
	    c.setName(getName(name));
	    c.setDayInWeeks(days);
	    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
	    c.setDate_creation(formatter.format(new Date()));
	    repository.add_service(c);
	    System.out.println(c);
	    
	  

	}

	public void update_service(){
	    
	    try {
		int code= Utils.promptIntValueWithLength("Entrez le code du service", 7);
		Service c = repository.findById(code);
		String name = choose_activity();
		 
		
		String debut = DateUtils.getDateInputOrNull("Entrez date de début du service. en format JJ-MM-AAAA / Repondre non");
		   
		String end = DateUtils.getDateInputOrNull("Entrez date de fin du service en format JJ-MM-AAAA / Repondre non" );
		   
		String hours = DateUtils.verifyHoursFormat("Entrez heure du services en format HH:MM / Repondre non" );
		        
		String recc = Utils.promptStringValuerWithMinAndMaxLength("Entrez récurrence hebdomadaire du service / Repondre non", 1, 5);
		    
		int capacity = Utils.promptIntValueWithUpperBond("Entrez le nombre de capacité maximale du service / Repondre non" , 30);
		      
		int profNumber = -1;
		int counter = 0;
		    
		      
		int fees = Utils.promptIntValueWithUpperBond("Entrez les frais du service / Repondre non", 100);
		   
		String comment = Utils.promptStringValuerWithMinAndMaxLength("Entrez commentaires (max 100 charactèrs) ou laissez le champ vide", 0, 100);
		    
		if(name.length()> 0 ) c.setName(name);
		
		if(!debut.equalsIgnoreCase("non") ) c.setStart_date(debut);
		if(!end.equalsIgnoreCase("non")) c.setEnd_date(end);
		if(!hours.equalsIgnoreCase("non")) c.setStart_hour(hours);
		if(!recc.equalsIgnoreCase("non")) c.setRecurrence(recc);
		if(capacity != -1) c.setMax_capacity(capacity);
		if(fees != -1 ) c.setFees(fees);
		System.out.println("Le service est modifer \n" + c);
		 
		
	    } catch (IOException e) {
		System.out.println("Code service incorrect");
	    }

	}
	
	
	public void delete_service() throws IOException{
	    
	    int code= Utils.promptIntValueWithLength("Entrez le code du service", 7);
	   ;
	    if( repository.delete(code)) {
		System.out.println("Service supprimer");
	    } else {
		System.out.println("Service non trouver");
	    }
	    

	}

	public Service get_service(int code){
		return repository.findById(code);
	}

	public static ServiceController getInstance() {
	    
	    return (single == null) ? new ServiceController() : single;
	}

	public Service getServiceToday(String today) {
	
	   
	   Scanner sc= new Scanner(System.in);
	   System.out.println("Veuillez choisir une seance par son code de service a 7 chiffres");
	  
	   if(! repository.getServiceToday(today)) {
	       return null;
	   }
	   String code = sc.nextLine();
	   int codeService = Utils.tryParse(code);
	   Service c = repository.findById(codeService);
	   if(c == null) System.out.println("code service incorrect");
	   return c;
	   
	    
	}
	
//	public void inscrireMembre(Membre m) {
//	    repository.addMemberToSeance(m);
//	}
//	
//	public void desincrireMembre(int uid) {
//	    repository.deleteMemberFromSeance(uid);
//	}
	
	public void test() {
	    Service c = new Service();
	    c.setDate_creation("06-08-2020 02:45:21");
	    c.setEnd_date("12-12-2020");
	    c.setStart_date("06-08-2020");
	    c.setFees(56.76);
	    ArrayList<String> dayInWeeks = new ArrayList<String>();
	    dayInWeeks.add("THURSDAY");
	    c.setDayInWeeks(dayInWeeks);
	    c.setMax_capacity(23);
	    c.setName("Tennis");
	    c.setStart_hour("12:45");
	    c.setProf_num(987654321);
	    c.setRecurrence("1");
	    c.setService_code(1122330);
	    c.setComment("pas de comment");
	    repository.add_service(c);
	   
	    
	}
	
	
	/**
	 * Affiches la listes des inscripts
	 * a une seance d'un  service
	 * superviser par un professionnel de la sante.
	 */
	public void display_inscrits(Professionnel curr) {
	    Scanner sc = new Scanner(System.in);
	    if(curr == null) {
		try {
		    String msg= "Entrez le numero a 9 chiffres du professionnel";   
		    int code = Utils.promptIntValueWithLength(msg, 9);
		    curr = ProfessionnalController.getInstance().getProfessionnel(code);
		} catch (Exception e) {};
		
	    }
	 
	  
		
		ArrayList<Service> tab = repository.getProfService(curr.getUid());
		if(tab.size() == 0) {
		    System.out.println("Le professionnel donne aucun service ");
		    return;
		}
		System.out.println("veuillez choisir une service pour la listes des inscripts");
		repository.displayService(tab);
		int codeService= Utils.tryParse(sc.nextLine());
		Service c = repository.findById(codeService);
		if(c == null) {
		    System.out.println("code service incorrect");
		    return;
		}
		c.print_all_inscripts();
		
	    
	    
	    
	}
	
	
	/**
	 * retourner la liste de service
	 * d'un professionnel
	 * @param uid_prof
	 * @return
	 */
	public ArrayList<Service> getProfsService(int uid_prof){
	    
	    return repository.getProfService(uid_prof);
	}
	
	
	private int getNewServiceCode(int profNum, String code_seance) {
	    return repository.generateSeanceCode(profNum, code_seance);
	}

	public ArrayList<Service> getMemberSeanceSuivi(int uid) {
	    return repository.member_followed_seance(uid);
	    
	}
	
	public  int generateSeanceCode(int profNum, String code_seance) {
	    return repository.generateSeanceCode(profNum, code_seance);
	}
	
	public int getServiceTotal() {
	    return repository.getServiceLength();
	}

	public ArrayList<Service> getAllService() {
	    // TODO Auto-generated method stub
	    return repository.getAllService();
	}
	

}