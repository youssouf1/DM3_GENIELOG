import java.time.LocalDateTime;
import java.util.ArrayList;


public class RepertoireService implements IRepertoire {


	private static ArrayList<Service> map = new ArrayList<>();

	private static RepertoireService  single;

	
	public void add_service(Service p){
	    map.add(p);
	}

	public void update_service(Service p){

	}

	public void delete_service(int code){
		
	}
	
	
	public ArrayList<Service> member_followed_seance(int memberUid){
	    
	    ArrayList<Service> tab = new ArrayList<Service>();
	    for(Service c : map) {
		
		for (Membre m : c.getAllMember()) {
		    if(m.getUid() == memberUid) {
			tab.add(c);
			break;
		    }
		}
	    }
	    return tab;
	}
	
	
	
	public Service findById(int code) {
	   
	    for (Service s : map) {
		if (s.getService_code() == code) {
	               return s;
	        }
	     }
	        return null;
	    }
	    
	    
	
	public ArrayList<Service> getProfService(int profcode) {
	  
	    ArrayList<Service> map2 = new ArrayList<Service>();
	    for (Service s : map) {
		if(s.getProf_num() == profcode) {
		    map2.add(s);
		}
	    }
	    return map2;
	}

       public IRepertoire create_new(){
	    
	    
	    return null;
	}

	public void modify_data(){}
	/**
	 * Supprimer un service
	 * @param code
	 * @return
	 */
	public boolean delete(int code) {
	    int j = -1;
	    for (int i = 0; i < map.size(); i++) {
	        if (code == map.get(i).getService_code()) {
	             j = i;
	              break;
	         }
	      }
	        if (j >= 0) map.remove(j);
	        return j >= 0;
	}
	public boolean delete_one(){
	    
	    
	    return false;
	}

	public static RepertoireService getInstance() {
	   
	    return (single == null )? new RepertoireService() : single;
	}
	
	public boolean getServiceToday(String today) {
	    LocalDateTime now = LocalDateTime.now();
	    int year = now.getYear();
	    int month = now.getMonthValue();
	    int jours = now.getDayOfMonth();
	    int hour = now.getHour();
	   
	    String heur_deb = hour +"";
	    heur_deb = (heur_deb.length() == 1)? "0"+heur_deb : heur_deb;
	    String service_today ="";
	   
	    for(Service c : map) {
		ArrayList<String> days = c.getDayInWeeks();
		
		for(String day : days) {
		    if(day.equalsIgnoreCase(today) && 
			    ((c.getStart_hour().compareTo(heur_deb))) >= 0) {
			service_today += c.getService_code() +". " + c.getName() + " a "
		    + c.getStart_hour()+"\n";
		    }
		}
		
	    }
	    if(service_today.equals("")) {
		System.out.println("Aucune seance disponible aujourd'hui");
		return false;
	    } else {
		 System.out.println("Seance disponible aujord'hui");
		 System.out.println(service_today);
		 return true;
	    }
	    
	    
	    
	    
	}
	
	
	    /**
	     * La fonction qui genere le code de seance a 7chiffres
	     * d'un service fournir par un professionnel.
	     *
	     * @return le code de seance a 7 chiffres dont 3 chiffres pour le id du service
	     * 2 chiffres aleatoire pour le jour du service et les 2 derniers chiffres
	     * du professionnel
	     */
	    public int generateSeanceCode(int profNumber,String serviceCode) {

	        String prof_last_digits = (""+profNumber).substring(7); // extrait de 2 derniers chiffres
	        String tmp = "";
	        int code;
	        int i =0;
	        do {
	            int day = (int) (Math.random() * 100); // le nombre aleatoire pour les 2chiffres



	            tmp = serviceCode + "" + (((""+ day).length() == 1)? "0"+ day: day) + prof_last_digits;
	            code = Utils.tryParse(tmp);
	            int time =0;
	            for( Service a : map) {
	        	if(a.getService_code() == code ) {
	        	    time++;
	        	}
	            }
	            if(time == 0 ) break;
	        } while (i++ < 100);
	     
	        return code;
	    }
	
	public void displayService(ArrayList<Service> tab) {
	    
	    for(Service c : tab) {
		
		System.out.println(c.getService_code() +" ." + c.getName() +" a " + c.getStart_hour());
	    }
	}

	public int getServiceLength() {
	    // TODO Auto-generated method stub
	    return map.size();
	}

	public ArrayList<Service> getAllService() {
	    
	    return map;
	}
	
	

	
}